# EvolveArena — tarayıcı / telefon girişi (pygbag)
import asyncio
import sys
import platform as pf
import pygame  # pygbag paketi bu satırdan tanır


def _say(t):
    try:
        pf.window.evoStatus(t)
    except Exception:
        pass


async def main():
    _say("Oyun yükleniyor...")
    await asyncio.sleep(0)
    try:
        import kasma_arena13 as ka
        _say("Hazırlanıyor...")
        await asyncio.sleep(0)
        app = ka.App()
    except BaseException as ex:
        import traceback
        txt = "".join(traceback.format_exception(ex))
        print(txt)
        _say("Açılış hatası: " + txt[-300:])
        try:
            pf.window.document.title = "BOOTERR " + txt[-900:].replace(chr(10), " | ")
        except Exception:
            pass
        return
    try:
        pf.window.evoHideSplash()
        pf.window.evoFit()
    except Exception:
        pass
    await app.run_loop_async()


asyncio.run(main())
